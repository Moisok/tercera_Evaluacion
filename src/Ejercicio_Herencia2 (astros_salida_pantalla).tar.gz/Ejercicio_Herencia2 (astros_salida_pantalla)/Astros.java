package Ejercicio_Herencia2;

public class Astros {
	
	//Artributos clase "padre"
	
	protected String nombre;
	
	protected double radio_ecuatorial;
	
	protected int rotacion_eje;
	
	protected int masa;
	
	protected double temp_media;
	
	protected double gravedad;
	
	
	//Contructor
	
	public Astros () {
		
	}

	public Astros ( String nombre, double radio_ecuatorial, int rotacion_eje, int masa, double temp_media, double gravedad) {
		
		this.radio_ecuatorial=radio_ecuatorial;
		
		this.rotacion_eje=rotacion_eje;
		
		this.masa=masa;
		
		this.temp_media=temp_media;
		
		this.gravedad=gravedad;
		
		this.nombre=nombre;
		
	}

	
	//Getters y setter

	public double getRadio_ecuatorial() {
		return radio_ecuatorial;
	}


	public int getRotacion_eje() {
		return rotacion_eje;
	}


	public int getMasa() {
		return masa;
	}


	public double getTemp_media() {
		return temp_media;
	}


	public double getGravedad() {
		return gravedad;
	}
	
	
	public String getNombre() {
		return nombre;
	}


	public void setRadio_ecuatorial(double radio_ecuatorial) {
		this.radio_ecuatorial = radio_ecuatorial;
	}


	public void setRotacion_eje(int rotacion_eje) {
		this.rotacion_eje = rotacion_eje;
	}


	public void setMasa(int masa) {
		this.masa = masa;
	}


	public void setTemp_media(double temp_media) {
		this.temp_media = temp_media;
	}


	public void setGravedad(double gravedad) {
		this.gravedad = gravedad;
	}

	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "Astros [nombre=" + nombre + ", radio_ecuatorial=" + radio_ecuatorial + ", rotacion_eje=" + rotacion_eje
				+ ", masa=" + masa + ", temp_media=" + temp_media + ", gravedad=" + gravedad + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
	//Metodo to String
	
	

	
	
	
	
	
	

}
